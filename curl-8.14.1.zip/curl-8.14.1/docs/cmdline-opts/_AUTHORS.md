<!-- Copyright (C) Daniel Stenberg, <daniel@haxx.se>, et al. -->
<!-- SPDX-License-Identifier: curl -->
# AUTHORS
Daniel Stenberg is the main author, but the whole list of contributors is
found in the separate THANKS file.
